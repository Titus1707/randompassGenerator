import java.security.SecureRandom;
import java.util.Scanner;

public class PasswordGenerator1 {

    private static final SecureRandom random = new SecureRandom();

    /** different dictionaries used */
    private static final String ALPHA_CAPS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String ALPHA = "abcdefghijklmnopqrstuvwxyz";
    private static final String NUMERIC = "0123456789";
    private static final String SPECIAL_CHARS = "!@#$%^&*_=+-/";
    private static final String SPECIAL_CHARS_EXTENDED = "&é'(§è!çà-)àç-}{^(";
    
    boolean pass = false;
    
    public static String generatePassword(int len, String dic) {
	String result = "";
	for (int i = 0; i < len; i++) {
	    int index = random.nextInt(dic.length());
	    result += dic.charAt(index);
	}
	return result;
    }

    public static void main(String[] args) {
        
         Scanner kb = new Scanner(System.in);
        System.out.println("--------------------------------------------------");
        System.out.println("--- Programme de génération de mots de passe ---");
        System.out.println("--------------------------------------------------");
        System.out.println("                                            ");
        System.out.println("Enter une largeur de mot de passe: ");
        
        int len =  Integer.parseInt(kb.nextLine());
        
        // condition de balise basse 
      
       // cond 1 
       
       if (len <=4)
       {
       System.out.println("Attention nombre trop petit, réésayez");
       }
       
       /*
        System.out.println("Largeur de mot de passe est de: "+len +" Caractéres");
	System.out.println("Password Generator Examples");
	System.out.println();

	
        System.out.println("Letter Password");
        System.out.println("Alphanumeric Lowercase password, length " + len + " chars: ");
	String password = generatePassword(len, ALPHA);
	System.out.println(password);
	System.out.println();
        
        System.out.println("Alphanumeric Uppercase password, length " + len + " chars: ");
	password = generatePassword(len, ALPHA_CAPS);
	System.out.println(password);
	System.out.println();
        
        System.out.println("Alphanumeric Uppercase + Lowercase password, length " + len + " chars: ");
	password = generatePassword(len, ALPHA+ALPHA_CAPS);
	System.out.println(password);
	System.out.println();
        
        System.out.println("Numeric password, length " + len + " chars: ");
	password = generatePassword(len, NUMERIC);
	System.out.println(password);
	System.out.println();
        
	System.out.println("Alphanumeric password, length " + len + " chars: ");
	password = generatePassword(len, ALPHA_CAPS + ALPHA);
	System.out.println(password);
	System.out.println();
 
	//len = 20;
	System.out.println("Alphanumeric + special password, length " + len + " chars: ");
	password = generatePassword(len, ALPHA_CAPS + ALPHA + SPECIAL_CHARS);
	System.out.println(password);
	System.out.println();

	//len = 15;
	System.out.println("Alphanumeric + numeric + special password, length " + len + " chars: ");
	password = generatePassword(len, ALPHA_CAPS + ALPHA + SPECIAL_CHARS + NUMERIC+SPECIAL_CHARS_EXTENDED);
	System.out.println(password);
	System.out.println();
        
        //len = 15;
	System.out.println("Alphanumeric + numeric + special password + EXTENDED FRENCH, length " + len + " chars: ");
	password = generatePassword(len, ALPHA_CAPS + ALPHA + SPECIAL_CHARS + NUMERIC);
	System.out.println(password);
	System.out.println();
*/   
}

    }
    
   }